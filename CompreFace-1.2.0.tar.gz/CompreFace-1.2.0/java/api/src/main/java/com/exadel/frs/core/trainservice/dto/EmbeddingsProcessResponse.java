package com.exadel.frs.core.trainservice.dto;

public interface EmbeddingsProcessResponse {

}
