package com.exadel.frs.commonservice.enums;

public enum TableLockName {

    MODEL_STATISTIC_LOCK
}
