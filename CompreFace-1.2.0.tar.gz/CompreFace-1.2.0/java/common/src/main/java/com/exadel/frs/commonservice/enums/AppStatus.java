package com.exadel.frs.commonservice.enums;

public enum AppStatus {
    OK,
    NOT_READY
}
