from src.services.utils.pyutils import get_current_dir

IMG_DIR = get_current_dir(__file__)
